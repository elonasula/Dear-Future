
# DearFuture

DearFuture är en tjänst där du kan skriva brev till ditt framtida jag – eller till dina barn. Du väljer när brevet ska levereras, och vi ser till att det skickas på rätt datum via post.

## Funktioner

- 📬 Skriv ett brev som sparas säkert tills det levereras
- 📅 Välj datum när brevet ska levereras
- 🖼️ Bifoga bild, ljud och video
- 🔐 Personnummer krävs för säker identifiering
- 🇸🇪 Just nu tillgängligt i Sverige

## Så fungerar det

1. Fyll i formuläret på hemsidan
2. Välj datum för framtida leverans
3. Vi skickar brevet via vanlig post när dagen kommer

---

🚀 Skapat med kärlek för framtiden.
